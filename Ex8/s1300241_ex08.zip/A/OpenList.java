public interface OpenList {
    public boolean isEmpty();
    public void push(int x);
    public int pop();
}



