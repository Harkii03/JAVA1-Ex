public interface Aggregate {
    Iterator forwardIterator();

    Iterator backwardIterator();
}