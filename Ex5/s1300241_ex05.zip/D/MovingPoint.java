public class MovingPoint extends Point {
    protected int dx;
    protected int dy;

    public MovingPoint(int x, int y) {
        super(x, y);
    }

}
