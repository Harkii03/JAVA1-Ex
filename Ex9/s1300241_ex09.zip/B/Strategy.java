interface Strategy {
    public void sort(int[] data);
}
